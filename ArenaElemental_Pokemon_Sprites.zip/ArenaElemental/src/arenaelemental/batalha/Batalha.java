package arenaelemental.batalha;

import arenaelemental.modelo.Criatura;
import java.util.List;
import java.util.ArrayList;

public class Batalha {
    private Criatura doJogador;
    private Criatura selvagem;
    private List<String> log = new ArrayList<>();

    public Batalha(Criatura doJogador, Criatura selvagem) {
        this.doJogador = doJogador;
        this.selvagem = selvagem;
        log.add("Um " + selvagem.getNome() + " selvagem apareceu!");
    }

    public Criatura getDoJogador() { return doJogador; }
    public Criatura getSelvagem() { return selvagem; }
    public List<String> getLog() { return log; }

    public void turno() {
        if (terminou()) return;
        int dano1 = doJogador.atacar(selvagem);
        log.add(doJogador.getNome() + " atacou e causou " + dano1 + " de dano!");
        if (!selvagem.estaViva()) {
            log.add(selvagem.getNome() + " selvagem foi derrotado!");
            return;
        }
        int dano2 = selvagem.atacar(doJogador);
        log.add(selvagem.getNome() + " revidou e causou " + dano2 + " de dano!");
        if (!doJogador.estaViva()) {
            log.add(doJogador.getNome() + " não pode continuar!");
        }
    }

    /** Troca o Pokémon ativo. A troca consome o turno e o adversário ataca depois. */
    public boolean trocarCriatura(Criatura nova) {
        if (terminou() || nova == null || !nova.estaViva() || nova == doJogador) return false;
        Criatura anterior = doJogador;
        doJogador = nova;
        log.add("Volte, " + anterior.getNome() + "! Vai, " + nova.getNome() + "!");

        if (selvagem.estaViva()) {
            int dano = selvagem.atacar(doJogador);
            log.add(selvagemNome() + " atacou durante a troca e causou " + dano + " de dano!");
            if (!doJogador.estaViva()) {
                log.add(doJogador.getNome() + " não pode continuar!");
            }
        }
        return true;
    }

    private String selvagemNome() { return selvagem.getNome() + " selvagem"; }

    public boolean terminou() { return !doJogador.estaViva() || !selvagem.estaViva(); }
}
