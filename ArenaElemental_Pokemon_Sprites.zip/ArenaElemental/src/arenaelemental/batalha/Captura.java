package arenaelemental.batalha;

import arenaelemental.modelo.Criatura;

public class Captura {
    public static double calcularChance(Criatura alvo) {
        double chance = 1.0 - alvo.percentualVida() * 0.75;
        return Math.max(0.15, Math.min(0.95, chance));
    }

    public static boolean tentar(Criatura alvo) {
        return Math.random() < calcularChance(alvo);
    }
}
