package arenaelemental.treinador;

import arenaelemental.modelo.Criatura;
import java.util.List;
import java.util.ArrayList;

public class Bestiario {
    private List<String> registradas = new ArrayList<>();

    public boolean registrar(Criatura c) {
        String especie = c.getClass().getSimpleName();
        if (registradas.contains(especie)) return false;
        registradas.add(especie);
        return true;
    }
    public List<String> getRegistradas() { return registradas; }
    public int total() { return registradas.size(); }

    /** Substitui o registro atual pelas espécies informadas, sem repetições (usado ao carregar um save). */
    public void restaurar(List<String> especies) {
        registradas.clear();
        for (String e : especies) if (!registradas.contains(e)) registradas.add(e);
    }
}

// =========================================================================
// BATALHA / CAPTURA
// =========================================================================
