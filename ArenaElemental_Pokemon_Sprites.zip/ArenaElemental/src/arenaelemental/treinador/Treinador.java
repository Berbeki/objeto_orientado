package arenaelemental.treinador;

import arenaelemental.modelo.Criatura;
import java.util.List;
import java.util.ArrayList;

public class Treinador {
    private static final int TAMANHO_MAX_EQUIPE = 6;
    private String nome;
    private List<Criatura> equipe = new ArrayList<>();

    public Treinador(String nome) { this.nome = nome; }
    public String getNome() { return nome; }
    public List<Criatura> getEquipe() { return equipe; }
    public static int getTamanhoMaxEquipe() { return TAMANHO_MAX_EQUIPE; }

    public boolean adicionarNaEquipe(Criatura c) {
        if (equipe.size() >= TAMANHO_MAX_EQUIPE) return false;
        equipe.add(c);
        return true;
    }

    public List<Criatura> getVivas() {
        List<Criatura> vivas = new ArrayList<>();
        for (Criatura c : equipe) if (c.estaViva()) vivas.add(c);
        return vivas;
    }

    public Criatura getAtiva() {
        for (Criatura c : equipe) if (c.estaViva()) return c;
        return null;
    }

    /** Cura toda a equipe (revive as desmaiadas). Retorna quantas criaturas realmente precisavam de cura. */
    public int curarEquipe() {
        int curadas = 0;
        for (Criatura c : equipe) {
            if (c.getVidaAtual() < c.getVidaMaxima()) {
                c.curarTotalmente();
                curadas++;
            }
        }
        return curadas;
    }

    /** true quando a equipe tem criaturas, mas nenhuma delas pode mais batalhar (fim de jogo). */
    public boolean todosDerrotados() {
        return !equipe.isEmpty() && getAtiva() == null;
    }
}
