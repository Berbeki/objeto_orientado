package arenaelemental.view;

import arenaelemental.modelo.Criatura;
import arenaelemental.persistencia.DadosSave;
import arenaelemental.persistencia.GerenciadorSave;
import arenaelemental.treinador.Treinador;
import arenaelemental.treinador.Bestiario;
import javax.swing.*;
import java.awt.*;
import java.io.IOException;

public class JanelaPrincipal extends JFrame {
    private CardLayout cardLayout = new CardLayout();
    private JPanel cartas = new JPanel(cardLayout);
    private Treinador treinador;
    private Bestiario bestiario = new Bestiario();
    private GerenciadorSave gerenciadorSave = GerenciadorSave.padrao();
    private PainelMenu painelMenu;
    private PainelBatalha painelBatalha;
    private PainelEquipe painelEquipe;
    private PainelGameOver painelGameOver;

    public JanelaPrincipal() {
        setTitle("Arena Elemental • Jornada");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(900, 650);
        setLocationRelativeTo(null);
        setResizable(false);

        painelMenu = new PainelMenu(this);
        painelBatalha = new PainelBatalha(this);
        painelEquipe = new PainelEquipe(this);
        painelGameOver = new PainelGameOver(this);

        cartas.add(painelMenu, "MENU");
        cartas.add(new PainelEscolha(this), "ESCOLHA");
        cartas.add(painelBatalha, "BATALHA");
        cartas.add(painelEquipe, "EQUIPE");
        cartas.add(painelGameOver, "GAMEOVER");

        add(cartas);
        mostrar("MENU");
    }

    void mostrar(String nome) {
        if (nome.equals("MENU")) painelMenu.atualizar();
        if (nome.equals("EQUIPE")) painelEquipe.atualizar();
        if (nome.equals("GAMEOVER")) painelGameOver.atualizar();
        cardLayout.show(cartas, nome);
    }

    void iniciarJornada(Criatura inicial) {
        treinador = new Treinador("Treinador");
        bestiario = new Bestiario(); // uma nova jornada começa com o bestiário vazio
        treinador.adicionarNaEquipe(inicial);
        bestiario.registrar(inicial);
        painelBatalha.iniciar(treinador);
        mostrar("BATALHA");
    }

    // ------------------------------------------------------------------
    // Salvar / carregar
    // ------------------------------------------------------------------

    boolean temSave() { return gerenciadorSave.existe(); }

    /** Só é permitido salvar fora de batalha (evita salvar no meio de uma luta). */
    boolean podeSalvar() { return treinador != null && !painelBatalha.emBatalha() && !treinador.todosDerrotados(); }

    void salvarJogo() {
        if (!podeSalvar()) return;
        try {
            gerenciadorSave.salvar(treinador, bestiario);
            painelBatalha.registrarMensagem("Jogo salvo com sucesso!");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Não foi possível salvar o jogo:\n" + e.getMessage(),
                    "Erro ao salvar", JOptionPane.ERROR_MESSAGE);
        }
    }

    boolean carregarJogo() {
        try {
            DadosSave dados = gerenciadorSave.carregar();
            treinador = dados.getTreinador();
            bestiario = dados.getBestiario();
            painelBatalha.iniciar(treinador, "Jogo carregado! Clique em Explorar para continuar sua jornada.");
            mostrar("BATALHA");
            return true;
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Não foi possível carregar o jogo:\n" + e.getMessage(),
                    "Erro ao carregar", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    // ------------------------------------------------------------------
    // Curar / game over
    // ------------------------------------------------------------------

    /** Curar só é permitido fora de batalha e enquanto ainda houver alguma criatura em pé. */
    boolean podeCurar() { return treinador != null && !painelBatalha.emBatalha() && !treinador.todosDerrotados(); }

    void curarEquipe() {
        if (!podeCurar()) return;
        int curadas = treinador.curarEquipe();
        painelBatalha.aoCurar(curadas);
        painelEquipe.atualizar();
    }

    void gameOver() { mostrar("GAMEOVER"); }

    Treinador getTreinador() { return treinador; }
    Bestiario getBestiario() { return bestiario; }
}
