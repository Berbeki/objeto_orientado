package arenaelemental.view;

import arenaelemental.modelo.TipoElemental;
import javax.swing.*;
import java.awt.*;

public class CartaoCriatura extends JPanel {
    CartaoCriatura(TipoElemental tipo, String nome, String habilidade, Runnable aoEscolher) {
        setLayout(new BorderLayout());
        setBackground(TemaPokemon.BRANCO);
        setBorder(TemaPokemon.bordaCartao());
        setPreferredSize(new Dimension(230, 300));

        JPanel spritePanel = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                CriaturaSprite.desenhar((Graphics2D) g, arenaelemental.modelo.FabricaCriaturas.criar(tipo, nome, 1, 1, 1), getWidth() / 2, getHeight() / 2 + 10, 120, false, false);
            }
        };
        spritePanel.setPreferredSize(new Dimension(230, 150));
        spritePanel.setOpaque(false);
        add(spritePanel, BorderLayout.NORTH);

        JPanel infoPanel = new JPanel();
        infoPanel.setOpaque(false);
        infoPanel.setLayout(new BoxLayout(infoPanel, BoxLayout.Y_AXIS));
        infoPanel.setBorder(BorderFactory.createEmptyBorder(4, 16, 8, 16));

        JLabel lblNome = new JLabel(nome);
        lblNome.setFont(new Font("Dialog", Font.BOLD, 20));
        lblNome.setForeground(Constantes.NAVY);
        lblNome.setAlignmentX(CENTER_ALIGNMENT);

        JLabel lblTipo = new JLabel("Tipo " + tipo.nomeExibicao());
        lblTipo.setFont(new Font("SansSerif", Font.BOLD, 13));
        lblTipo.setForeground(tipo.corPrincipal());
        lblTipo.setAlignmentX(CENTER_ALIGNMENT);

        JTextArea lblHabilidade = new JTextArea(habilidade);
        lblHabilidade.setFont(new Font("SansSerif", Font.PLAIN, 12));
        lblHabilidade.setForeground(Constantes.MUTED);
        lblHabilidade.setLineWrap(true);
        lblHabilidade.setWrapStyleWord(true);
        lblHabilidade.setOpaque(false);
        lblHabilidade.setEditable(false);
        lblHabilidade.setFocusable(false);
        lblHabilidade.setAlignmentX(CENTER_ALIGNMENT);
        lblHabilidade.setMaximumSize(new Dimension(190, 60));

        infoPanel.add(lblNome);
        infoPanel.add(Box.createVerticalStrut(4));
        infoPanel.add(lblTipo);
        infoPanel.add(Box.createVerticalStrut(8));
        infoPanel.add(lblHabilidade);
        add(infoPanel, BorderLayout.CENTER);

        JButton btn = new JButton("Escolher");
        TemaPokemon.estilizarBotao(btn, TemaPokemon.VERMELHO);
        btn.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(TemaPokemon.VERMELHO_ESCURO, 2),
                BorderFactory.createEmptyBorder(8, 0, 8, 0)));
        btn.addActionListener(e -> aoEscolher.run());
        add(btn, BorderLayout.SOUTH);
    }
}
