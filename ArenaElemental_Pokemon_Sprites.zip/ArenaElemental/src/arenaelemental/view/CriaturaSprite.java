package arenaelemental.view;

import arenaelemental.modelo.Criatura;
import arenaelemental.modelo.TipoElemental;
import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

/**
 * Renderiza os sprites reais do repositório PokeAPI/sprites.
 * Usa os sprites de FireRed/LeafGreen (Geração III): frente para o selvagem
 * e costas para o Pokémon do jogador. Se estiver offline e o sprite ainda
 * não tiver sido baixado, usa o desenho de emergência por tipo.
 */
public class CriaturaSprite {
    private static final Map<String, Integer> IDS = new HashMap<>();
    private static final Map<String, BufferedImage> CACHE = new HashMap<>();
    private static final Path CACHE_DIR = Paths.get(System.getProperty("user.home"), ".arenaelemental", "sprites");
    private static final String BASE = "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iii/firered-leafgreen/";

    static {
        IDS.put("Bulbasaur", 1);
        IDS.put("Charmander", 4);
        IDS.put("Squirtle", 7);
        // compatibilidade com criaturas antigas do projeto
        IDS.put("Ivysaur", 1);
        IDS.put("Oddish", 1);
        IDS.put("Charmeleon", 4);
        IDS.put("Vulpix", 4);
        IDS.put("Wartortle", 7);
        IDS.put("Psyduck", 7);
    }

    static void desenhar(Graphics2D g, Criatura criatura, int cx, int cy, int tamanho, boolean desmaiado, boolean costas) {
        if (criatura == null) return;
        Integer id = IDS.get(criatura.getNome());
        if (id != null) {
            BufferedImage img = carregar(id, costas);
            if (img != null) {
                desenharImagem(g, img, cx, cy, tamanho, desmaiado);
                return;
            }
        }
        desenharFallback(g, criatura.getTipo(), cx, cy, tamanho, desmaiado);
    }

    static void desenhar( Graphics2D g, TipoElemental tipo, int cx, int cy, int tamanho, boolean desmaiado) {
        // Mantido para telas antigas que só conhecem o tipo.
        desenharFallback(g, tipo, cx, cy, tamanho, desmaiado);
    }

    private static BufferedImage carregar(int id, boolean costas) {
        String chave = id + (costas ? "_back" : "_front");
        if (CACHE.containsKey(chave)) return CACHE.get(chave);
        try {
            Files.createDirectories(CACHE_DIR);
            Path arquivo = CACHE_DIR.resolve(chave + ".png");
            BufferedImage img = null;
            if (Files.exists(arquivo)) img = ImageIO.read(arquivo.toFile());
            if (img == null) {
                String url = BASE + (costas ? "back/" : "") + id + ".png";
                URLConnection conexao = new URL(url).openConnection();
                conexao.setConnectTimeout(2500);
                conexao.setReadTimeout(3500);
                conexao.setRequestProperty("User-Agent", "ArenaElemental/1.0");
                try (InputStream in = conexao.getInputStream()) {
                    img = ImageIO.read(in);
                }
                if (img != null) ImageIO.write(img, "png", arquivo.toFile());
            }
            if (img != null) CACHE.put(chave, img);
            return img;
        } catch (Exception ignored) {
            return null;
        }
    }

    private static void desenharImagem(Graphics2D g, BufferedImage img, int cx, int cy, int tamanho, boolean desmaiado) {
        int largura = tamanho;
        int altura = tamanho;
        double escala = Math.min((double) tamanho / img.getWidth(), (double) tamanho / img.getHeight());
        largura = Math.max(1, (int) Math.round(img.getWidth() * escala));
        altura = Math.max(1, (int) Math.round(img.getHeight() * escala));

        g.setColor(new Color(0, 0, 0, 40));
        g.fillOval(cx - tamanho / 2 + 8, cy + tamanho / 2 - 10, tamanho - 16, 16);
        if (desmaiado) {
            Composite antigo = g.getComposite();
            g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.45f));
            g.drawImage(img, cx - largura / 2, cy - altura / 2, largura, altura, null);
            g.setComposite(antigo);
            g.setColor(new Color(70, 70, 80, 180));
            g.setStroke(new BasicStroke(4f));
            g.drawLine(cx - tamanho / 4, cy - tamanho / 4, cx + tamanho / 4, cy + tamanho / 4);
            g.drawLine(cx - tamanho / 4, cy + tamanho / 4, cx + tamanho / 4, cy - tamanho / 4);
        } else {
            g.drawImage(img, cx - largura / 2, cy - altura / 2, largura, altura, null);
        }
    }

    private static void desenharFallback(Graphics2D g, TipoElemental tipo, int cx, int cy, int tamanho, boolean desmaiado) {
        Object oldHint = g.getRenderingHint(RenderingHints.KEY_ANTIALIASING);
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        Color cor = desmaiado ? new Color(160, 160, 165) : tipo.corPrincipal();
        int r = tamanho / 2;
        g.setColor(new Color(0, 0, 0, 40));
        g.fillOval(cx - r + 6, cy + r - 8, tamanho - 12, 18);
        g.setColor(cor); g.fillOval(cx-r, cy-r, tamanho, tamanho);
        g.setColor(cor.darker()); g.setStroke(new BasicStroke(3f)); g.drawOval(cx-r, cy-r, tamanho, tamanho);
        g.setColor(Color.WHITE); g.fillOval(cx-r/2-8, cy-r/6-8, 16, 16); g.fillOval(cx+r/2-8, cy-r/6-8, 16, 16);
        g.setColor(Color.BLACK); g.fillOval(cx-r/2-4, cy-r/6-4, 8, 8); g.fillOval(cx+r/2-4, cy-r/6-4, 8, 8);
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, oldHint == null ? RenderingHints.VALUE_ANTIALIAS_DEFAULT : oldHint);
    }
}
