package arenaelemental.view;

import arenaelemental.modelo.Criatura;
import arenaelemental.treinador.Treinador;
import javax.swing.*;
import java.awt.*;
import java.util.List;

/** Tela exibida quando todas as criaturas da equipe foram derrotadas. */
public class PainelGameOver extends JPanel {
    private JanelaPrincipal janela;
    private JLabel lblResumo = new JLabel(" ", SwingConstants.CENTER);
    private JButton btnCarregar;

    PainelGameOver(JanelaPrincipal janela) {
        this.janela = janela;
        setLayout(new GridBagLayout());
        setBackground(TemaPokemon.AZUL_ESCURO);
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0; c.insets = new Insets(8, 0, 8, 0);

        JLabel titulo = new JLabel("FIM DE JOGO");
        titulo.setFont(new Font("Dialog", Font.BOLD, 46));
        titulo.setForeground(Constantes.PERIGO);
        c.gridy = 0; add(titulo, c);

        JLabel subtitulo = new JLabel("Todas as suas criaturas foram derrotadas.");
        subtitulo.setFont(new Font("SansSerif", Font.PLAIN, 16));
        subtitulo.setForeground(Color.WHITE);
        c.gridy = 1; add(subtitulo, c);

        // equipe desmaiada, desenhada com o mesmo sprite "desmaiado" usado na batalha
        JPanel sprites = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Treinador t = janela.getTreinador();
                if (t == null) return;
                List<Criatura> equipe = t.getEquipe();
                int passo = 100;
                int inicioX = (getWidth() - equipe.size() * passo) / 2 + passo / 2;
                for (int i = 0; i < equipe.size(); i++) {
                    CriaturaSprite.desenhar((Graphics2D) g, equipe.get(i),
                            inicioX + i * passo, getHeight() / 2, 64, true, true);
                }
            }
        };
        sprites.setOpaque(false);
        sprites.setPreferredSize(new Dimension(620, 120));
        c.gridy = 2; add(sprites, c);

        lblResumo.setFont(new Font("SansSerif", Font.PLAIN, 14));
        lblResumo.setForeground(Constantes.MUTED.brighter());
        c.gridy = 3; add(lblResumo, c);

        btnCarregar = PainelMenu.criarBotao("Carregar último save", Constantes.AMBER);
        btnCarregar.addActionListener(e -> janela.carregarJogo());
        c.gridy = 4; c.insets = new Insets(30, 0, 8, 0); add(btnCarregar, c);

        JButton btnNova = PainelMenu.criarBotao("Nova Jornada", Constantes.CYAN);
        btnNova.addActionListener(e -> janela.mostrar("ESCOLHA"));
        c.gridy = 5; c.insets = new Insets(8, 0, 8, 0); add(btnNova, c);

        JButton btnMenu = PainelMenu.criarBotao("Menu principal", Constantes.NAVY2);
        btnMenu.addActionListener(e -> janela.mostrar("MENU"));
        c.gridy = 6; add(btnMenu, c);
    }

    void atualizar() {
        Treinador t = janela.getTreinador();
        int criaturas = t != null ? t.getEquipe().size() : 0;
        lblResumo.setText("Equipe: " + criaturas + " criatura(s)  ·  Bestiário: "
                + janela.getBestiario().total() + " espécie(s) registrada(s)");
        boolean temSave = janela.temSave();
        btnCarregar.setEnabled(temSave);
        btnCarregar.setToolTipText(temSave ? null : "Nenhum jogo salvo ainda");
        repaint();
    }
}
