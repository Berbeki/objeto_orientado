package arenaelemental.view;

import javax.swing.*;
import java.awt.*;

/** Ícone decorativo desenhado em Swing para reforçar a identidade visual. */
public class BolaTreino extends JComponent {
    public BolaTreino() { setPreferredSize(new Dimension(92, 92)); }
    @Override protected void paintComponent(Graphics graphics) {
        Graphics2D g=(Graphics2D)graphics.create();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        int d=Math.min(getWidth(),getHeight())-8, x=(getWidth()-d)/2, y=(getHeight()-d)/2;
        g.setColor(Color.WHITE); g.fillOval(x,y,d,d);
        g.setColor(TemaPokemon.VERMELHO); g.fillArc(x,y,d,d,0,180);
        g.setColor(TemaPokemon.TEXTO); g.fillRect(x,y+d/2-3,d,6);
        g.setColor(Color.WHITE); g.fillOval(x+d/2-13,y+d/2-13,26,26);
        g.setColor(TemaPokemon.TEXTO); g.drawOval(x,y,d,d);
        g.drawOval(x+d/2-13,y+d/2-13,26,26);
        g.dispose();
    }
}
