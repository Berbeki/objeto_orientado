package arenaelemental.view;

import arenaelemental.modelo.TipoElemental;
import arenaelemental.modelo.Criatura;
import javax.swing.*;
import java.awt.*;

/** Campo de batalha com linguagem visual inspirada em jogos clássicos de captura. */
public class PainelArena extends JPanel {
    private Criatura criaturaEsquerda, criaturaDireita;
    private boolean desmaioEsquerda, desmaioDireita;

    PainelArena() {
        setOpaque(false);
        setPreferredSize(new Dimension(650, 280));
        setBorder(BorderFactory.createLineBorder(TemaPokemon.AZUL_ESCURO, 3, true));
    }

    void configurar(Criatura esquerda, boolean desmaioEsq, Criatura direita, boolean desmaioDir) {
        this.criaturaEsquerda = esquerda; this.desmaioEsquerda = desmaioEsq;
        this.criaturaDireita = direita; this.desmaioDireita = desmaioDir;
        repaint();
    }

    @Override protected void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);
        Graphics2D g = (Graphics2D) graphics.create();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int w = getWidth(), h = getHeight();
        GradientPaint sky = new GradientPaint(0, 0, new Color(155, 215, 245), 0, h * 0.62f, new Color(235, 245, 250));
        g.setPaint(sky);
        g.fillRoundRect(0, 0, w, h, 20, 20);

        // nuvens estilizadas
        g.setColor(new Color(255,255,255,180));
        g.fillOval(45, 35, 90, 28); g.fillOval(75, 22, 70, 42);
        g.fillOval(w-160, 50, 95, 28); g.fillOval(w-125, 36, 65, 40);

        // terreno
        g.setColor(new Color(145, 198, 101));
        g.fillRect(0, (int)(h*0.60), w, (int)(h*0.40));
        g.setColor(new Color(92, 155, 76));
        g.fillOval(-80, h-105, 390, 150);
        g.fillOval(w-310, h-105, 390, 150);

        // plataformas
        g.setColor(new Color(88, 119, 72));
        g.fillOval(55, h-82, 230, 42);
        g.setColor(new Color(184, 214, 116));
        g.fillOval(65, h-88, 210, 30);

        g.setColor(new Color(88, 119, 72));
        g.fillOval(w-285, 110, 230, 38);
        g.setColor(new Color(184, 214, 116));
        g.fillOval(w-275, 104, 210, 28);

        // criaturas
        if (criaturaEsquerda != null)
            CriaturaSprite.desenhar(g, criaturaEsquerda, 165, h - 105, 145, desmaioEsquerda, true);
        if (criaturaDireita != null)
            CriaturaSprite.desenhar(g, criaturaDireita, w - 165, 105, 125, desmaioDireita, false);

        g.dispose();
    }
}
