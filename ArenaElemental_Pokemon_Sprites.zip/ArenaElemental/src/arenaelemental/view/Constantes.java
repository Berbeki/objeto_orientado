package arenaelemental.view;

import java.awt.Color;

public class Constantes {
    static final Color NAVY = TemaPokemon.AZUL_ESCURO;
    static final Color NAVY2 = TemaPokemon.AZUL;
    static final Color CYAN = new Color(55, 153, 224);
    static final Color AMBER = TemaPokemon.AMARELO;
    static final Color LIGHT = TemaPokemon.CREME;
    static final Color MUTED = new Color(92, 103, 116);
    static final Color PERIGO = TemaPokemon.VERMELHO;
}
