package arenaelemental.view;

import arenaelemental.modelo.Criatura;
import javax.swing.*;
import java.awt.*;

public class BarraVida extends JPanel {
    private Criatura criatura;

    public BarraVida(Criatura criatura) {
        this.criatura = criatura;
        setOpaque(false);
        setPreferredSize(new Dimension(250, 60));
    }

    public void setCriatura(Criatura c) { this.criatura = c; repaint(); }

    @Override
    protected void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);
        if (criatura == null) return;
        Graphics2D g = (Graphics2D) graphics;
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        g.setFont(new Font("SansSerif", Font.BOLD, 15));
        g.setColor(TemaPokemon.TEXTO);
        g.drawString(criatura.getNome(), 2, 16);

        g.setFont(new Font("SansSerif", Font.PLAIN, 11));
        g.setColor(TemaPokemon.TEXTO);
        g.drawString(criatura.getTipo().nomeExibicao(), getWidth() - 46, 16);

        int barW = getWidth() - 4, barH = 16, barY = 22;
        g.setColor(new Color(42, 48, 56));
        g.fillRoundRect(2, barY, barW, barH, 8, 8);

        double pct = Math.max(0, criatura.percentualVida());
        int fillW = (int) (barW * pct);
        Color cor = pct > 0.5 ? TemaPokemon.VERDE : (pct > 0.2 ? TemaPokemon.AMARELO : TemaPokemon.VERMELHO);
        g.setColor(cor);
        if (fillW > 0) g.fillRoundRect(2, barY, fillW, barH, 8, 8);
        g.setColor(new Color(190, 195, 202));
        g.drawRoundRect(2, barY, barW, barH, 8, 8);

        g.setFont(new Font("SansSerif", Font.PLAIN, 11));
        g.setColor(TemaPokemon.TEXTO);
        g.drawString(criatura.getVidaAtual() + " / " + criatura.getVidaMaxima() + " HP", 2, barY + barH + 14);
    }
}
