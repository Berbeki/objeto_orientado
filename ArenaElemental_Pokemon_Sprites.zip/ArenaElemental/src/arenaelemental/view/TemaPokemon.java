package arenaelemental.view;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/** Tema visual inspirado em RPGs de captura de monstros, sem depender de imagens externas. */
public final class TemaPokemon {
    private TemaPokemon() {}

    public static final Color VERMELHO = new Color(214, 44, 56);
    public static final Color VERMELHO_ESCURO = new Color(151, 25, 38);
    public static final Color AZUL = new Color(35, 86, 145);
    public static final Color AZUL_ESCURO = new Color(24, 55, 96);
    public static final Color AMARELO = new Color(255, 203, 59);
    public static final Color CREME = new Color(250, 247, 235);
    public static final Color BRANCO = Color.WHITE;
    public static final Color TEXTO = new Color(38, 47, 58);
    public static final Color VERDE = new Color(74, 156, 88);

    public static Border bordaCartao() {
        return BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(55, 70, 90), 2, true),
                BorderFactory.createEmptyBorder(8, 8, 8, 8));
    }

    public static void estilizarBotao(JButton b, Color fundo) {
        b.setFont(new Font("Dialog", Font.BOLD, 14));
        b.setBackground(fundo);
        b.setForeground(Color.WHITE);
        b.setFocusPainted(false);
        b.setOpaque(true);
        b.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(fundo.darker(), 2, true),
                BorderFactory.createEmptyBorder(8, 14, 8, 14)));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) {
                if (b.isEnabled()) b.setBackground(fundo.brighter());
            }
            @Override public void mouseExited(MouseEvent e) {
                b.setBackground(fundo);
            }
        });
    }

    public static JLabel titulo(String texto, int tamanho, Color cor) {
        JLabel l = new JLabel(texto);
        l.setFont(new Font("Dialog", Font.BOLD, tamanho));
        l.setForeground(cor);
        return l;
    }
}
