package arenaelemental.view;

import arenaelemental.modelo.Criatura;
import arenaelemental.modelo.FabricaCriaturas;
import arenaelemental.treinador.Treinador;
import arenaelemental.batalha.Batalha;
import arenaelemental.batalha.Captura;
import javax.swing.*;
import java.awt.*;
import java.util.List;

public class PainelBatalha extends JPanel {
    private JanelaPrincipal janela;
    private PainelArena arena = new PainelArena();
    private BarraVida barraJogador, barraSelvagem;
    private JTextArea logArea = new JTextArea();
    private JButton btnAtacar, btnCapturar, btnFugir, btnExplorar, btnCurar, btnSalvar, btnTrocar;
    private boolean fimDeJogo;
    private JLabel lblStatus = new JLabel(" ");
    private Batalha batalhaAtual;

    PainelBatalha(JanelaPrincipal janela) {
        this.janela = janela;
        setLayout(new BorderLayout(10, 10));
        setBackground(TemaPokemon.CREME);
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel topo = new JPanel(new BorderLayout());
        topo.setOpaque(false);
        lblStatus.setFont(new Font("Dialog", Font.BOLD, 14));
        lblStatus.setForeground(Constantes.MUTED);
        topo.add(lblStatus, BorderLayout.WEST);
        JPanel acoesTopo = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        acoesTopo.setOpaque(false);
        btnCurar = new JButton("Curar equipe");
        estilizarBotaoSecundario(btnCurar);
        btnCurar.addActionListener(e -> janela.curarEquipe());
        btnSalvar = new JButton("Salvar jogo");
        estilizarBotaoSecundario(btnSalvar);
        btnSalvar.addActionListener(e -> janela.salvarJogo());
        JButton btnEquipe = new JButton("Equipe / Bestiário");
        estilizarBotaoSecundario(btnEquipe);
        btnEquipe.addActionListener(e -> janela.mostrar("EQUIPE"));
        acoesTopo.add(btnCurar);
        acoesTopo.add(btnSalvar);
        acoesTopo.add(btnEquipe);
        topo.add(acoesTopo, BorderLayout.EAST);
        add(topo, BorderLayout.NORTH);

        JPanel centro = new JPanel(new BorderLayout(8, 8));
        centro.setOpaque(false);
        centro.add(arena, BorderLayout.CENTER);

        JPanel painelBarras = new JPanel(new BorderLayout());
        painelBarras.setOpaque(false);
        barraJogador = new BarraVida(null);
        barraSelvagem = new BarraVida(null);
        JPanel esqBarra = new JPanel(); esqBarra.setOpaque(false); esqBarra.add(barraJogador);
        JPanel dirBarra = new JPanel(); dirBarra.setOpaque(false); dirBarra.add(barraSelvagem);
        painelBarras.add(esqBarra, BorderLayout.WEST);
        painelBarras.add(dirBarra, BorderLayout.EAST);
        centro.add(painelBarras, BorderLayout.SOUTH);
        add(centro, BorderLayout.CENTER);

        JPanel lado = new JPanel();
        lado.setLayout(new BoxLayout(lado, BoxLayout.Y_AXIS));
        lado.setPreferredSize(new Dimension(230, 10));
        lado.setOpaque(false);

        logArea.setEditable(false);
        logArea.setLineWrap(true);
        logArea.setWrapStyleWord(true);
        logArea.setFont(new Font("SansSerif", Font.PLAIN, 13));
        logArea.setBackground(TemaPokemon.AZUL_ESCURO);
        logArea.setForeground(Color.WHITE);
        logArea.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        JScrollPane scroll = new JScrollPane(logArea);
        scroll.setPreferredSize(new Dimension(230, 150));
        scroll.setBorder(BorderFactory.createEmptyBorder());
        lado.add(scroll);
        lado.add(Box.createVerticalStrut(12));

        btnExplorar = criarBotaoAcao("Explorar", Constantes.CYAN);
        btnExplorar.addActionListener(e -> explorar());
        btnAtacar = criarBotaoAcao("LUTAR", Constantes.AMBER);
        btnAtacar.addActionListener(e -> atacar());
        btnCapturar = criarBotaoAcao("CAPTURAR", Constantes.CYAN);
        btnCapturar.addActionListener(e -> capturar());
        btnFugir = criarBotaoAcao("FUGIR", Constantes.NAVY2);
        btnFugir.addActionListener(e -> fugir());
        btnTrocar = criarBotaoAcao("Trocar Pokémon", Constantes.CYAN);
        btnTrocar.addActionListener(e -> trocarPokemon());

        lado.add(btnExplorar);
        lado.add(Box.createVerticalStrut(8));
        lado.add(btnAtacar);
        lado.add(Box.createVerticalStrut(8));
        lado.add(btnCapturar);
        lado.add(Box.createVerticalStrut(8));
        lado.add(btnTrocar);
        lado.add(Box.createVerticalStrut(8));
        lado.add(btnFugir);

        add(lado, BorderLayout.EAST);
        atualizarBotoes(false);
    }

    private void estilizarBotaoSecundario(JButton b) {
        TemaPokemon.estilizarBotao(b, TemaPokemon.AZUL);
        b.setFont(new Font("Dialog", Font.BOLD, 12));
        b.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(TemaPokemon.AZUL_ESCURO, 1, true),
                BorderFactory.createEmptyBorder(6, 10, 6, 10)));
    }

    private JButton criarBotaoAcao(String texto, Color cor) {
        JButton b = new JButton(texto);
        TemaPokemon.estilizarBotao(b, cor);
        b.setFont(new Font("Dialog", Font.BOLD, 14));
        b.setAlignmentX(Component.LEFT_ALIGNMENT);
        b.setMaximumSize(new Dimension(220, 44));
        b.setPreferredSize(new Dimension(220, 44));
        return b;
    }

    void iniciar(Treinador t) {
        iniciar(t, "Sua jornada começa! Clique em Explorar para encontrar uma criatura selvagem.");
    }

    void iniciar(Treinador t, String mensagemInicial) {
        fimDeJogo = false;
        batalhaAtual = null;
        Criatura ativa = t.getAtiva();
        barraJogador.setCriatura(ativa);
        barraSelvagem.setCriatura(null);
        arena.configurar(ativa, ativa != null && !ativa.estaViva(), null, false);
        lblStatus.setText("Treinador: " + t.getNome() + "  ·  Equipe: " + t.getEquipe().size() + "/" + Treinador.getTamanhoMaxEquipe());
        logArea.setText(mensagemInicial + "\n");
        atualizarBotoes(false);
    }

    /** true enquanto há uma batalha em andamento (ainda não decidida). */
    boolean emBatalha() { return batalhaAtual != null && !batalhaAtual.terminou(); }

    void registrarMensagem(String mensagem) { logArea.append(mensagem + "\n"); }

    /** Chamado depois que a equipe é curada: atualiza log, barra de vida e arena. */
    void aoCurar(int curadas) {
        if (curadas == 0) {
            logArea.append("Sua equipe já está com a vida cheia.\n");
        } else {
            logArea.append("Sua equipe foi curada! (" + curadas
                    + (curadas == 1 ? " criatura recuperada)" : " criaturas recuperadas)") + "\n");
        }
        Criatura ativa = janela.getTreinador().getAtiva();
        barraJogador.setCriatura(ativa);
        barraSelvagem.setCriatura(null);
        arena.configurar(ativa, false, null, false);
    }


    private void explorar() {
        Criatura ativa = janela.getTreinador().getAtiva();
        if (ativa == null) {
            logArea.append("Sua equipe não tem nenhuma criatura em condições de batalhar!\n");
            return;
        }
        Criatura selvagem = FabricaCriaturas.selvagemAleatorio();
        batalhaAtual = new Batalha(ativa, selvagem);
        barraJogador.setCriatura(ativa);
        barraSelvagem.setCriatura(selvagem);
        arena.configurar(ativa, false, selvagem, false);
        logArea.setText("");
        for (String linha : batalhaAtual.getLog()) logArea.append(linha + "\n");
        atualizarBotoes(true);
    }

    private void atacar() {
        if (batalhaAtual == null || batalhaAtual.terminou()) return;
        batalhaAtual.turno();
        atualizarLog();
        atualizarArena();
        if (batalhaAtual.terminou()) {
            if (!batalhaAtual.getSelvagem().estaViva()) {
                janela.getBestiario().registrar(batalhaAtual.getSelvagem());
                logArea.append("Você venceu a batalha!\n");
            }
            aoTerminarBatalha();
        }
    }

    private void atualizarArena() {
        arena.configurar(batalhaAtual.getDoJogador(), !batalhaAtual.getDoJogador().estaViva(),
                batalhaAtual.getSelvagem(), !batalhaAtual.getSelvagem().estaViva());
        barraJogador.repaint();
        barraSelvagem.repaint();
    }

    /**
     * Chamado quando uma batalha termina. Se a criatura do jogador caiu e não sobrou mais
     * ninguém na equipe, é fim de jogo; se ainda sobrou alguém, avisa quem será o próximo.
     */
    private void aoTerminarBatalha() {
        Treinador t = janela.getTreinador();
        if (t.todosDerrotados()) {
            fimDeJogo = true;
            atualizarBotoes(false);
            logArea.append("Todas as suas criaturas foram derrotadas...\n");
            // pequena pausa para o jogador ver o que aconteceu antes da tela de game over
            Timer timer = new Timer(1800, e -> janela.gameOver());
            timer.setRepeats(false);
            timer.start();
            return;
        }
        atualizarBotoes(false);
        if (!batalhaAtual.getDoJogador().estaViva()) {
            Criatura proxima = null;
            for (Criatura c : t.getVivas()) {
                if (c != batalhaAtual.getDoJogador()) { proxima = c; break; }
            }
            if (proxima != null) {
                logArea.append("Próximo Pokémon disponível: " + proxima.getNome() + ". Use Trocar Pokémon para escolhê-lo.\n");
            }
        }
    }

    private void capturar() {
        if (batalhaAtual == null || batalhaAtual.terminou()) return;
        Criatura selvagem = batalhaAtual.getSelvagem();
        if (Captura.tentar(selvagem)) {
            logArea.append("Você capturou " + selvagem.getNome() + "!\n");
            janela.getBestiario().registrar(selvagem);
            if (!janela.getTreinador().adicionarNaEquipe(selvagem)) {
                logArea.append("(Equipe cheia — a criatura foi registrada no Bestiário, mas não coube no time)\n");
            }
            batalhaAtual = null;
            atualizarBotoes(false);
        } else {
            logArea.append(selvagem.getNome() + " escapou da captura!\n");
            batalhaAtual.turno();
            atualizarLog();
            atualizarArena();
            if (batalhaAtual.terminou()) aoTerminarBatalha();
        }
    }

    private void trocarPokemon() {
        if (batalhaAtual == null || batalhaAtual.terminou()) return;

        Treinador treinador = janela.getTreinador();
        List<Criatura> vivas = treinador.getVivas();
        if (vivas.size() <= 1) {
            logArea.append("Você não tem outro Pokémon vivo para trocar.\n");
            return;
        }

        Criatura atual = batalhaAtual.getDoJogador();
        Criatura[] opcoes = vivas.stream()
                .filter(c -> c != atual)
                .toArray(Criatura[]::new);
        String[] nomes = new String[opcoes.length];
        for (int i = 0; i < opcoes.length; i++) {
            Criatura c = opcoes[i];
            nomes[i] = c.getNome() + "  [" + c.getTipo() + "]  HP "
                    + c.getVidaAtual() + "/" + c.getVidaMaxima();
        }

        int escolha = JOptionPane.showOptionDialog(this,
                "Escolha o Pokémon que entrará na batalha:",
                "Trocar Pokémon", JOptionPane.DEFAULT_OPTION,
                JOptionPane.PLAIN_MESSAGE, null, nomes, nomes[0]);

        if (escolha >= 0 && batalhaAtual.trocarCriatura(opcoes[escolha])) {
            barraJogador.setCriatura(batalhaAtual.getDoJogador());
            atualizarArena();
            atualizarLogCompleto();
            if (batalhaAtual.terminou()) aoTerminarBatalha();
        }
    }

    private void fugir() {
        logArea.append("Você fugiu da batalha.\n");
        batalhaAtual = null;
        arena.configurar(janela.getTreinador().getAtiva(), false, null, false);
        atualizarBotoes(false);
    }

    private void atualizarLogCompleto() {
        logArea.setText("");
        for (String linha : batalhaAtual.getLog()) logArea.append(linha + "\n");
        logArea.setCaretPosition(logArea.getDocument().getLength());
    }

    private void atualizarLog() {
        List<String> log = batalhaAtual.getLog();
        logArea.append(log.get(log.size() - 1) + "\n");
        if (log.size() >= 2) {
            // mostra também a penúltima linha se for nova (ataque do jogador + resposta)
        }
    }

    private void atualizarBotoes(boolean emBatalha) {
        btnExplorar.setVisible(!emBatalha);
        btnExplorar.setEnabled(!fimDeJogo);
        btnCurar.setEnabled(!emBatalha && !fimDeJogo);
        btnSalvar.setEnabled(!emBatalha && !fimDeJogo);
        btnAtacar.setVisible(emBatalha);
        btnCapturar.setVisible(emBatalha);
        btnFugir.setVisible(emBatalha);
        btnTrocar.setVisible(emBatalha);
        btnTrocar.setEnabled(emBatalha);
    }
}
