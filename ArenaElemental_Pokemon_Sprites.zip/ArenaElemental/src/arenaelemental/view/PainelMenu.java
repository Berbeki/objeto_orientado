package arenaelemental.view;

import javax.swing.*;
import java.awt.*;

public class PainelMenu extends JPanel {
    private JanelaPrincipal janela;
    private JButton btnContinuar;

    PainelMenu(JanelaPrincipal janela) {
        this.janela = janela;
        setLayout(new GridBagLayout());
        setBackground(TemaPokemon.AZUL_ESCURO);
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0; c.insets = new Insets(10, 0, 10, 0);

        JLabel titulo = new JLabel("ARENA ELEMENTAL");
        titulo.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(TemaPokemon.AMARELO, 3, true), BorderFactory.createEmptyBorder(8, 18, 8, 18)));
        titulo.setFont(new Font("Dialog", Font.BOLD, 42));
        titulo.setForeground(Color.WHITE);
        c.gridy = 0; add(titulo, c);

        BolaTreino bola = new BolaTreino();
        c.gridy = 1; c.insets = new Insets(12, 0, 2, 0); add(bola, c);

        JLabel subtitulo = new JLabel("CAPTURE  •  TREINE  •  BATALHE");
        subtitulo.setFont(new Font("Dialog", Font.BOLD, 15));
        subtitulo.setForeground(TemaPokemon.AMARELO);
        c.gridy = 2; add(subtitulo, c);

        btnContinuar = criarBotao("Continuar", Constantes.AMBER);
        btnContinuar.addActionListener(e -> janela.carregarJogo());
        c.gridy = 3; c.insets = new Insets(34, 0, 10, 0); add(btnContinuar, c);

        JButton btnJogar = criarBotao("Nova Jornada", TemaPokemon.VERMELHO);
        btnJogar.addActionListener(e -> janela.mostrar("ESCOLHA"));
        c.gridy = 4; c.insets = new Insets(8, 0, 8, 0); add(btnJogar, c);

        JButton btnSair = criarBotao("Sair", TemaPokemon.AZUL);
        btnSair.addActionListener(e -> System.exit(0));
        c.gridy = 5; add(btnSair, c);

        atualizar();
    }

    /** Habilita "Continuar" somente se existir um jogo salvo. */
    void atualizar() {
        boolean temSave = janela.temSave();
        btnContinuar.setEnabled(temSave);
        btnContinuar.setToolTipText(temSave ? null : "Nenhum jogo salvo ainda");
    }

    static JButton criarBotao(String texto, Color cor) {
        JButton b = new JButton(texto);
        b.setPreferredSize(new Dimension(260, 50));
        TemaPokemon.estilizarBotao(b, cor);
        return b;
    }
}
