package arenaelemental.view;

import arenaelemental.modelo.Criatura;
import javax.swing.*;
import java.awt.*;

public class PainelEquipe extends JPanel {
    private JanelaPrincipal janela;
    private JPanel listaEquipe = new JPanel();
    private JLabel lblBestiario = new JLabel();
    private JButton btnCurar;

    PainelEquipe(JanelaPrincipal janela) {
        this.janela = janela;
        setLayout(new BorderLayout(12, 12));
        setBackground(TemaPokemon.CREME);
        setBorder(BorderFactory.createEmptyBorder(24, 24, 24, 24));

        JLabel titulo = new JLabel("Sua equipe");
        titulo.setFont(new Font("Dialog", Font.BOLD, 28));
        titulo.setForeground(TemaPokemon.AZUL_ESCURO);
        add(titulo, BorderLayout.NORTH);

        listaEquipe.setLayout(new FlowLayout(FlowLayout.LEFT, 14, 14));
        listaEquipe.setOpaque(false);
        JScrollPane scroll = new JScrollPane(listaEquipe);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        add(scroll, BorderLayout.CENTER);

        JPanel rodape = new JPanel(new BorderLayout());
        rodape.setOpaque(false);
        lblBestiario.setFont(new Font("SansSerif", Font.BOLD, 14));
        lblBestiario.setForeground(Constantes.MUTED);
        rodape.add(lblBestiario, BorderLayout.WEST);
        btnCurar = new JButton("Curar equipe");
        TemaPokemon.estilizarBotao(btnCurar, TemaPokemon.VERDE);
        btnCurar.addActionListener(e -> janela.curarEquipe());
        JButton btnVoltar = new JButton("Voltar para a exploração");
        TemaPokemon.estilizarBotao(btnVoltar, TemaPokemon.VERMELHO);
        btnVoltar.addActionListener(e -> janela.mostrar("BATALHA"));
        JPanel acoes = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        acoes.setOpaque(false);
        acoes.add(btnCurar);
        acoes.add(btnVoltar);
        rodape.add(acoes, BorderLayout.EAST);
        add(rodape, BorderLayout.SOUTH);
    }

    void atualizar() {
        listaEquipe.removeAll();
        for (Criatura c : janela.getTreinador().getEquipe()) {
            listaEquipe.add(criarMiniCartao(c));
        }
        lblBestiario.setText("Bestiário: " + janela.getBestiario().total() + " espécie(s) registrada(s)");
        boolean podeCurar = janela.podeCurar();
        btnCurar.setEnabled(podeCurar);
        btnCurar.setToolTipText(podeCurar ? null : "Não é possível curar durante uma batalha");
        listaEquipe.revalidate();
        listaEquipe.repaint();
    }

    private JPanel criarMiniCartao(Criatura c) {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(TemaPokemon.BRANCO);
        p.setBorder(TemaPokemon.bordaCartao());
        p.setPreferredSize(new Dimension(270, 110));

        JPanel spriteP = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                CriaturaSprite.desenhar((Graphics2D) g, c, getWidth() / 2, getHeight() / 2, 80, !c.estaViva(), true);
            }
        };
        spriteP.setOpaque(false);
        spriteP.setPreferredSize(new Dimension(100, 100));
        p.add(spriteP, BorderLayout.WEST);

        JPanel info = new JPanel();
        info.setOpaque(false);
        info.setLayout(new BoxLayout(info, BoxLayout.Y_AXIS));
        info.setBorder(BorderFactory.createEmptyBorder(10, 6, 10, 10));
        JLabel nome = new JLabel(c.getNome());
        nome.setFont(new Font("SansSerif", Font.BOLD, 15));
        nome.setForeground(Constantes.NAVY);
        JLabel tipo = new JLabel(c.getTipo().nomeExibicao());
        tipo.setFont(new Font("SansSerif", Font.PLAIN, 12));
        tipo.setForeground(c.getTipo().corPrincipal());
        JLabel vida = new JLabel(c.getVidaAtual() + "/" + c.getVidaMaxima() + " HP");
        vida.setFont(new Font("SansSerif", Font.PLAIN, 12));
        vida.setForeground(Constantes.MUTED);
        info.add(nome); info.add(tipo); info.add(vida);
        p.add(info, BorderLayout.CENTER);
        return p;
    }
}

// =========================================================================
// JANELA PRINCIPAL
// =========================================================================
