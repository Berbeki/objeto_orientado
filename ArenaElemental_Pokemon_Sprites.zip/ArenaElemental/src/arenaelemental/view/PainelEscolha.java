package arenaelemental.view;

import arenaelemental.modelo.TipoElemental;
import arenaelemental.modelo.FabricaCriaturas;
import javax.swing.*;
import java.awt.*;

public class PainelEscolha extends JPanel {
    PainelEscolha(JanelaPrincipal janela) {
        setLayout(new BorderLayout());
        setBackground(TemaPokemon.CREME);
        setBorder(BorderFactory.createEmptyBorder(24, 30, 24, 30));

        JLabel titulo = new JLabel("Escolha sua primeira criatura", SwingConstants.CENTER);
        titulo.setFont(new Font("Dialog", Font.BOLD, 28));
        titulo.setForeground(TemaPokemon.AZUL_ESCURO);
        add(titulo, BorderLayout.NORTH);

        JPanel cartas = new JPanel(new FlowLayout(FlowLayout.CENTER, 24, 20));
        cartas.setOpaque(false);
        cartas.add(new CartaoCriatura(TipoElemental.FOGO, "Braseiro", "Labareda: dano extra contra alvos enfraquecidos",
                () -> janela.iniciarJornada(FabricaCriaturas.novaInicial(TipoElemental.FOGO))));
        cartas.add(new CartaoCriatura(TipoElemental.AGUA, "Marulho", "Maré Cheia: dano extra com a vida acima de 50%",
                () -> janela.iniciarJornada(FabricaCriaturas.novaInicial(TipoElemental.AGUA))));
        cartas.add(new CartaoCriatura(TipoElemental.PLANTA, "Folharal", "Sugar Seiva: recupera vida a cada ataque",
                () -> janela.iniciarJornada(FabricaCriaturas.novaInicial(TipoElemental.PLANTA))));
        add(cartas, BorderLayout.CENTER);
    }
}
