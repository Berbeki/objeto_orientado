package arenaelemental.persistencia;

import arenaelemental.treinador.Bestiario;
import arenaelemental.treinador.Treinador;

/** Resultado de carregar um jogo salvo: o treinador (com a equipe) e o bestiário. */
public class DadosSave {
    private final Treinador treinador;
    private final Bestiario bestiario;

    public DadosSave(Treinador treinador, Bestiario bestiario) {
        this.treinador = treinador;
        this.bestiario = bestiario;
    }

    public Treinador getTreinador() { return treinador; }
    public Bestiario getBestiario() { return bestiario; }
}
