package arenaelemental.persistencia;

import arenaelemental.modelo.Criatura;
import arenaelemental.modelo.FabricaCriaturas;
import arenaelemental.modelo.TipoElemental;
import arenaelemental.treinador.Bestiario;
import arenaelemental.treinador.Treinador;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

/**
 * Salva e carrega o progresso do jogador (equipe + bestiário) em um arquivo de texto
 * no formato .properties (UTF-8). Existe um único slot de save.
 */
public class GerenciadorSave {
    private static final String VERSAO = "1";
    private final Path arquivo;

    public GerenciadorSave(Path arquivo) { this.arquivo = arquivo; }

    /** Save padrão do jogo: {user.home}/.arenaelemental/save.properties */
    public static GerenciadorSave padrao() {
        return new GerenciadorSave(Paths.get(System.getProperty("user.home"), ".arenaelemental", "save.properties"));
    }

    public Path getArquivo() { return arquivo; }

    public boolean existe() { return Files.isRegularFile(arquivo); }

    public void salvar(Treinador treinador, Bestiario bestiario) throws IOException {
        Properties p = new Properties();
        p.setProperty("versao", VERSAO);
        p.setProperty("treinador.nome", treinador.getNome());
        p.setProperty("bestiario", String.join(",", bestiario.getRegistradas()));

        List<Criatura> equipe = treinador.getEquipe();
        p.setProperty("equipe.tamanho", String.valueOf(equipe.size()));
        for (int i = 0; i < equipe.size(); i++) {
            Criatura c = equipe.get(i);
            String pre = "equipe." + i + ".";
            p.setProperty(pre + "tipo", c.getTipo().name());
            p.setProperty(pre + "nome", c.getNome());
            p.setProperty(pre + "vidaMaxima", String.valueOf(c.getVidaMaxima()));
            p.setProperty(pre + "vidaAtual", String.valueOf(c.getVidaAtual()));
            p.setProperty(pre + "ataque", String.valueOf(c.getAtaque()));
            p.setProperty(pre + "defesa", String.valueOf(c.getDefesa()));
        }

        Path pasta = arquivo.toAbsolutePath().getParent();
        if (pasta != null) Files.createDirectories(pasta);

        // grava num arquivo temporário e só então troca: um erro no meio da gravação não estraga o save antigo
        Path temporario = arquivo.resolveSibling(arquivo.getFileName() + ".tmp");
        try (Writer w = Files.newBufferedWriter(temporario, StandardCharsets.UTF_8)) {
            p.store(w, "Arena Elemental - jogo salvo");
        }
        try {
            Files.move(temporario, arquivo, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
        } catch (AtomicMoveNotSupportedException e) {
            Files.move(temporario, arquivo, StandardCopyOption.REPLACE_EXISTING);
        }
    }

    public DadosSave carregar() throws IOException {
        if (!existe()) throw new IOException("Nenhum jogo salvo foi encontrado.");
        Properties p = new Properties();
        try (Reader r = Files.newBufferedReader(arquivo, StandardCharsets.UTF_8)) {
            p.load(r);
        }
        try {
            int tamanho = inteiro(p, "equipe.tamanho");
            if (tamanho < 1 || tamanho > Treinador.getTamanhoMaxEquipe()) {
                throw new IllegalArgumentException("tamanho de equipe inválido: " + tamanho);
            }
            Treinador treinador = new Treinador(texto(p, "treinador.nome"));
            for (int i = 0; i < tamanho; i++) {
                String pre = "equipe." + i + ".";
                TipoElemental tipo = TipoElemental.valueOf(texto(p, pre + "tipo"));
                int vidaMaxima = inteiro(p, pre + "vidaMaxima");
                int ataque = inteiro(p, pre + "ataque");
                int defesa = inteiro(p, pre + "defesa");
                if (vidaMaxima < 1 || ataque < 1 || defesa < 0) {
                    throw new IllegalArgumentException("atributos inválidos na criatura " + (i + 1));
                }
                Criatura c = FabricaCriaturas.criar(tipo, texto(p, pre + "nome"), vidaMaxima, ataque, defesa);
                c.restaurarVida(inteiro(p, pre + "vidaAtual"));
                treinador.adicionarNaEquipe(c);
            }

            if (treinador.todosDerrotados()) {
                throw new IllegalArgumentException("nenhuma criatura em condições de batalhar");
            }

            List<String> especies = new ArrayList<>();
            for (String e : p.getProperty("bestiario", "").split(",")) {
                if (!e.trim().isEmpty()) especies.add(e.trim());
            }
            Bestiario bestiario = new Bestiario();
            bestiario.restaurar(especies);
            return new DadosSave(treinador, bestiario);
        } catch (IllegalArgumentException e) { // inclui NumberFormatException e tipo elemental inexistente
            throw new IOException("O arquivo de save está corrompido ou incompleto (" + e.getMessage() + ").", e);
        }
    }

    private static String texto(Properties p, String chave) {
        String v = p.getProperty(chave);
        if (v == null) throw new IllegalArgumentException("campo ausente: " + chave);
        return v;
    }

    private static int inteiro(Properties p, String chave) {
        return Integer.parseInt(texto(p, chave).trim());
    }
}
