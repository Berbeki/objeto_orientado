package arenaelemental.modelo;

public class Folharal extends Criatura {
    public Folharal(String nome, int vida, int ataque, int defesa) {
        super(nome, TipoElemental.PLANTA, vida, ataque, defesa);
    }
    protected double bonusEspecial(Criatura alvo) { return 1.0; }
    protected void efeitoPosAtaque(Criatura alvo, int danoAplicado) {
        curar((int) Math.round(danoAplicado * 0.2));
    }
    public String descricaoHabilidade() {
        return "Sugar Seiva: recupera 20% do dano causado como vida";
    }
}

// =========================================================================
// TREINADOR / BESTIARIO
// =========================================================================
