package arenaelemental.modelo;

public class FabricaCriaturas {
    private static final String[] NOMES_FOGO = {"Charmander"};
    private static final String[] NOMES_AGUA = {"Squirtle"};
    private static final String[] NOMES_PLANTA = {"Bulbasaur"};

    public static Criatura novaInicial(TipoElemental tipo) {
        switch (tipo) {
            case FOGO: return new Braseiro("Charmander", 42, 13, 8);
            case AGUA: return new Marulho("Squirtle", 46, 11, 10);
            case PLANTA: return new Folharal("Bulbasaur", 44, 11, 9);
        }
        throw new IllegalArgumentException("Tipo desconhecido");
    }

    public static Criatura criar(TipoElemental tipo, String nome, int vida, int ataque, int defesa) {
        switch (tipo) {
            case FOGO: return new Braseiro(nome, vida, ataque, defesa);
            case AGUA: return new Marulho(nome, vida, ataque, defesa);
            case PLANTA: return new Folharal(nome, vida, ataque, defesa);
        }
        throw new IllegalArgumentException("Tipo desconhecido");
    }

    public static Criatura selvagemAleatorio() {
        TipoElemental[] tipos = TipoElemental.values();
        TipoElemental tipo = tipos[(int) (Math.random() * tipos.length)];
        int vida = 24 + (int) (Math.random() * 18);
        int ataque = 7 + (int) (Math.random() * 7);
        int defesa = 5 + (int) (Math.random() * 6);
        switch (tipo) {
            case FOGO: return new Braseiro(escolher(NOMES_FOGO), vida, ataque, defesa);
            case AGUA: return new Marulho(escolher(NOMES_AGUA), vida, ataque, defesa);
            default: return new Folharal(escolher(NOMES_PLANTA), vida, ataque, defesa);
        }
    }

    private static String escolher(String[] opcoes) {
        return opcoes[(int) (Math.random() * opcoes.length)];
    }
}
