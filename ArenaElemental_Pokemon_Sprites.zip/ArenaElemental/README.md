# Arena Elemental

Projeto de referência para o trabalho **Pokémon — Captura e Batalha** (1º bimestre,
Opção C). Sistema de captura e batalha de criaturas por turnos, com interface
gráfica em Java Swing.

## Sobre as criaturas

As criaturas deste projeto (**Braseiro**, **Marulho**, **Folharal**) e a arte de
todos os sprites são **originais**, desenhadas em código com Java2D — nenhuma
imagem, nome ou personagem da franquia Pokémon foi usado, já que é propriedade
da Nintendo/Game Freak. A mecânica (tipos elementares, captura, equipe, batalha
por turnos) é inspirada no gênero, não na obra específica.

## Estrutura do projeto

```
src/arenaelemental/
├── Main.java                  → ponto de entrada
├── modelo/
│   ├── TipoElemental.java     → enum com a lógica de vantagem de tipo
│   ├── Criatura.java          → classe abstrata base (estado + comportamento)
│   ├── Braseiro.java          → tipo Fogo (habilidade: Labareda)
│   ├── Marulho.java           → tipo Água (habilidade: Maré Cheia)
│   ├── Folharal.java          → tipo Planta (habilidade: Sugar Seiva)
│   └── FabricaCriaturas.java  → cria criaturas iniciais e encontros selvagens
├── treinador/
│   ├── Treinador.java         → equipe do jogador (até 6 criaturas)
│   └── Bestiario.java         → registro de espécies já vistas/capturadas
├── batalha/
│   ├── Batalha.java           → laço de turnos entre duas criaturas
│   └── Captura.java           → cálculo da chance de captura
└── view/                      → toda a interface gráfica (Swing)
    ├── CriaturaSprite.java    → desenho original de cada criatura
    ├── BarraVida.java         → componente de barra de vida
    ├── PainelArena.java       → cenário de batalha
    ├── CartaoCriatura.java    → cartão usado na tela de escolha inicial
    ├── PainelMenu.java        → tela inicial
    ├── PainelEscolha.java     → escolha da criatura inicial
    ├── PainelBatalha.java     → tela principal (explorar, atacar, capturar, fugir)
    ├── PainelEquipe.java      → equipe do treinador + bestiário
    └── JanelaPrincipal.java   → janela principal (CardLayout entre as telas)

test/arenaelemental/           → testes unitários (JUnit 5), mesma estrutura de pacotes
```

## Como compilar e rodar

Requer JDK 11 ou superior (testado com JDK 21).

```bash
# a partir da raiz do projeto
javac -d out $(find src -name "*.java")
java -cp out arenaelemental.Main
```

## Como rodar os testes unitários

Os testes usam JUnit 5 (Jupiter). Se você não usa Maven/Gradle, o jeito mais
simples é baixar o **JUnit Console Standalone** e rodar:

```bash
javac -d out $(find src -name "*.java")
javac -cp out:junit-platform-console-standalone.jar -d out-test $(find test -name "*.java")
java -jar junit-platform-console-standalone.jar -cp out:out-test --scan-classpath
```

Se preferir Maven/Gradle, basta apontar `src` como source root, `test` como
test root, e adicionar a dependência `org.junit.jupiter:junit-jupiter:5.10.0`
(ou versão mais recente) no escopo de teste.

## Mecânica de tipos

Fogo vence Planta · Planta vence Água · Água vence Fogo (vantagem: 1.5x dano,
desvantagem: 0.67x dano) — a lógica fica centralizada em
`TipoElemental.vantagemSobre(...)`, então adicionar um novo tipo não exige
reescrever o código de batalha.

## Habilidades especiais (polimorfismo)

Cada subclasse de `Criatura` sobrescreve `bonusEspecial(...)` e, quando faz
sentido, `efeitoPosAtaque(...)`:

- **Braseiro** (Fogo): +30% de dano contra alvos com vida abaixo de 30%
- **Marulho** (Água): +15% de dano enquanto a própria vida estiver acima de 50%
- **Folharal** (Planta): recupera 20% do dano causado como vida a cada ataque


## Atualização Pokémon
- Criaturas iniciais: Charmander (Fogo), Squirtle (Água) e Bulbasaur (Planta).
- Encontros selvagens usam espécies Pokémon dos três tipos.
- Durante a batalha existe o botão **Trocar Pokémon**.
- A troca seleciona qualquer Pokémon vivo da equipe, atualiza o HUD e consome o turno: o adversário pode atacar durante a troca.
- A lógica de captura, exploração, cura e salvamento foi preservada.
