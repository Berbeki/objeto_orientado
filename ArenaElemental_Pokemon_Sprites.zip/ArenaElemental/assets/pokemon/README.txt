SPRITES POKEMON

O projeto usa exatamente os sprites de FireRed/LeafGreen do repositório PokeAPI/sprites.
IDs usados:
1  = Bulbasaur
4  = Charmander
7  = Squirtle

O programa baixa os PNGs na primeira execução e os salva em:
~/.arenaelemental/sprites/

URLs oficiais do repositório:
https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iii/firered-leafgreen/1.png
https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iii/firered-leafgreen/4.png
https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iii/firered-leafgreen/7.png

Costas:
https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iii/firered-leafgreen/back/1.png
https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iii/firered-leafgreen/back/4.png
https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iii/firered-leafgreen/back/7.png
