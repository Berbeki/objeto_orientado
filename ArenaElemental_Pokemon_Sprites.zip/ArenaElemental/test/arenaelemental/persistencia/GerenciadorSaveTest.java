package arenaelemental.persistencia;

import arenaelemental.modelo.Braseiro;
import arenaelemental.modelo.Criatura;
import arenaelemental.modelo.Folharal;
import arenaelemental.modelo.Marulho;
import arenaelemental.modelo.TipoElemental;
import arenaelemental.treinador.Bestiario;
import arenaelemental.treinador.Treinador;
import org.junit.jupiter.api.Test;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import static org.junit.jupiter.api.Assertions.*;

public class GerenciadorSaveTest {

    private GerenciadorSave novoGerenciador() throws IOException {
        Path pasta = Files.createTempDirectory("arena-save-test");
        pasta.toFile().deleteOnExit();
        Path arquivo = pasta.resolve("sub").resolve("save.properties"); // a subpasta ainda nao existe
        arquivo.toFile().deleteOnExit();
        arquivo.getParent().toFile().deleteOnExit();
        return new GerenciadorSave(arquivo);
    }

    @Test
    void semSaveNaoExisteECarregarFalha() throws IOException {
        GerenciadorSave g = novoGerenciador();
        assertFalse(g.existe());
        assertThrows(IOException.class, g::carregar);
    }

    @Test
    void salvarECarregarPreservaEquipeVidaEBestiario() throws IOException {
        Treinador t = new Treinador("Ana");
        Criatura ferida = new Braseiro("Ignivo", 42, 13, 8);
        ferida.receberDano(25); // 17/42
        Criatura desmaiada = new Marulho("Aquário", 46, 11, 10); // acento: exige UTF-8
        desmaiada.receberDano(100);
        Criatura cheia = new Folharal("Folharal", 44, 11, 9);
        t.adicionarNaEquipe(ferida);
        t.adicionarNaEquipe(desmaiada);
        t.adicionarNaEquipe(cheia);
        Bestiario b = new Bestiario();
        b.registrar(ferida);
        b.registrar(desmaiada);

        GerenciadorSave g = novoGerenciador();
        g.salvar(t, b);
        assertTrue(g.existe());

        DadosSave dados = g.carregar();
        Treinador lido = dados.getTreinador();
        assertEquals("Ana", lido.getNome());
        assertEquals(3, lido.getEquipe().size());

        Criatura c0 = lido.getEquipe().get(0);
        assertEquals(Braseiro.class, c0.getClass(), "A especie (subclasse) deve ser recriada corretamente");
        assertEquals("Ignivo", c0.getNome());
        assertEquals(TipoElemental.FOGO, c0.getTipo());
        assertEquals(42, c0.getVidaMaxima());
        assertEquals(17, c0.getVidaAtual());
        assertEquals(13, c0.getAtaque());
        assertEquals(8, c0.getDefesa());

        Criatura c1 = lido.getEquipe().get(1);
        assertEquals(Marulho.class, c1.getClass());
        assertEquals("Aquário", c1.getNome());
        assertFalse(c1.estaViva(), "Uma criatura desmaiada deve continuar desmaiada apos carregar");

        Criatura c2 = lido.getEquipe().get(2);
        assertEquals(Folharal.class, c2.getClass());
        assertEquals(44, c2.getVidaAtual());

        assertEquals(b.getRegistradas(), dados.getBestiario().getRegistradas());
    }

    @Test
    void salvarSubstituiOSaveAnterior() throws IOException {
        GerenciadorSave g = novoGerenciador();
        Treinador primeiro = new Treinador("Primeiro");
        primeiro.adicionarNaEquipe(new Braseiro("Um", 30, 10, 5));
        g.salvar(primeiro, new Bestiario());
        Treinador segundo = new Treinador("Segundo");
        segundo.adicionarNaEquipe(new Marulho("Dois", 30, 10, 5));
        g.salvar(segundo, new Bestiario());

        DadosSave dados = g.carregar();
        assertEquals("Segundo", dados.getTreinador().getNome());
        assertEquals("Dois", dados.getTreinador().getEquipe().get(0).getNome());
    }

    @Test
    void arquivoCorrompidoLancaIOException() throws IOException {
        GerenciadorSave g = novoGerenciador();
        Files.createDirectories(g.getArquivo().getParent());
        Files.write(g.getArquivo(), "equipe.tamanho=abc\n".getBytes(StandardCharsets.UTF_8));
        assertThrows(IOException.class, g::carregar);
    }

    @Test
    void campoAusenteLancaIOException() throws IOException {
        GerenciadorSave g = novoGerenciador();
        Files.createDirectories(g.getArquivo().getParent());
        Files.write(g.getArquivo(),
                ("treinador.nome=Ana\nequipe.tamanho=1\nequipe.0.tipo=FOGO\n").getBytes(StandardCharsets.UTF_8));
        assertThrows(IOException.class, g::carregar);
    }

    @Test
    void tipoInexistenteLancaIOException() throws IOException {
        GerenciadorSave g = novoGerenciador();
        Files.createDirectories(g.getArquivo().getParent());
        String conteudo = "treinador.nome=Ana\nequipe.tamanho=1\nequipe.0.tipo=ELETRICO\nequipe.0.nome=X\n"
                + "equipe.0.vidaMaxima=30\nequipe.0.vidaAtual=30\nequipe.0.ataque=10\nequipe.0.defesa=5\n";
        Files.write(g.getArquivo(), conteudo.getBytes(StandardCharsets.UTF_8));
        assertThrows(IOException.class, g::carregar);
    }

    @Test
    void saveComEquipeInteiraDerrotadaEhRejeitado() throws IOException {
        Treinador t = new Treinador("Ana");
        Criatura c = new Braseiro("Caida", 30, 10, 5);
        c.receberDano(30);
        t.adicionarNaEquipe(c);
        GerenciadorSave g = novoGerenciador();
        g.salvar(t, new Bestiario());
        assertThrows(IOException.class, g::carregar,
                "Um save sem nenhuma criatura em condicoes de batalhar nao deve ser carregado");
    }
}
