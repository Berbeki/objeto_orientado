package arenaelemental.treinador;

import arenaelemental.modelo.Criatura;
import arenaelemental.modelo.Marulho;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TreinadorTest {

    @Test
    void naoAdicionaAlemDoLimiteDeSeis() {
        Treinador t = new Treinador("Ana");
        for (int i = 0; i < 6; i++) {
            assertTrue(t.adicionarNaEquipe(new Marulho("C" + i, 20, 5, 5)));
        }
        boolean adicionouSetima = t.adicionarNaEquipe(new Marulho("Setima", 20, 5, 5));
        assertFalse(adicionouSetima, "Nao deve ser possivel adicionar uma setima criatura na equipe");
        assertEquals(6, t.getEquipe().size());
    }

    @Test
    void getAtivaRetornaPrimeiraCriaturaViva() {
        Treinador t = new Treinador("Ana");
        Criatura desmaiada = new Marulho("Desmaiada", 20, 5, 5);
        desmaiada.receberDano(20);
        Criatura viva = new Marulho("Viva", 20, 5, 5);
        t.adicionarNaEquipe(desmaiada);
        t.adicionarNaEquipe(viva);
        assertEquals(viva, t.getAtiva(), "getAtiva deve pular criaturas desmaiadas e retornar a primeira viva");
    }

    @Test
    void curarEquipeRestauraVidaERevive() {
        Treinador t = new Treinador("Ana");
        Criatura ferida = new Marulho("Ferida", 20, 5, 5);
        ferida.receberDano(8);
        Criatura desmaiada = new Marulho("Desmaiada", 20, 5, 5);
        desmaiada.receberDano(20);
        t.adicionarNaEquipe(ferida);
        t.adicionarNaEquipe(desmaiada);
        int curadas = t.curarEquipe();
        assertEquals(2, curadas);
        assertEquals(20, ferida.getVidaAtual());
        assertTrue(desmaiada.estaViva(), "Curar a equipe deve reviver as criaturas desmaiadas");
        assertEquals(20, desmaiada.getVidaAtual());
    }

    @Test
    void curarEquipeNaoContaCriaturasJaSaudaveis() {
        Treinador t = new Treinador("Ana");
        t.adicionarNaEquipe(new Marulho("Saudavel", 20, 5, 5));
        assertEquals(0, t.curarEquipe());
    }

    @Test
    void todosDerrotadosSoQuandoNenhumaCriaturaEstaViva() {
        Treinador t = new Treinador("Ana");
        Criatura a = new Marulho("A", 20, 5, 5);
        Criatura b = new Marulho("B", 20, 5, 5);
        t.adicionarNaEquipe(a);
        t.adicionarNaEquipe(b);
        assertFalse(t.todosDerrotados());
        a.receberDano(20);
        assertFalse(t.todosDerrotados(), "Ainda existe uma criatura viva na equipe");
        b.receberDano(20);
        assertTrue(t.todosDerrotados());
    }

    @Test
    void equipeVaziaNaoEhFimDeJogo() {
        assertFalse(new Treinador("Ana").todosDerrotados());
    }
}
